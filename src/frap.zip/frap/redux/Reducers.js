import user from './LoginSlice';
import organization from './UserOrganizationSlice';
// import userLocation from './LocationSlice';
import editUserProfile from './UserSlice';
// import editProfile from './ProfileSlice';
// import editRoleProfile from './RoleSlice';
// import editOrganization from './OrganizationSlice';
// import MenuSlice from './MenuSlice';
// import changeQuoteStatus from './QuoteRequestSlice';
// import cometchatSlice from './cometchatSlice';
// import dashboardSidebar from './dashboardSidebarSlice';
// import SidebarNotifications from './sidebarNotificationsSlice';

const reducers = {
  user,
  organization,
//   userLocation,
//   editProfile,
  editUserProfile,
//   editRoleProfile,
//   editOrganization,
//   menus: MenuSlice,
//   changeQuoteStatus,
//   cometchatSlice,
//   SidebarNotifications,
  // dashboardSidebar,
};

export default reducers;
