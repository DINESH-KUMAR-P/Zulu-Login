import React from 'react'

  export const isProd = false;
  export const cookieName = "zulu_token";
//   export const googleTagManagerId = "GTM-PNGC6Q4";
//   export const googleTrackingid = "G-8N0TC85ZJ7";
//   export const fbPixelId = "2672511839725718";
//   export const commetChatAppId = "34441bb54112e4a";
//   export const cometChatSuffix = isProd ? "prod" : "dev";
//   export const commetChatRegion = "us";
//   export const cometChatPaginationLimit = 20;
//   export const cometChatContactpaginatinLimit = 50;
//   export const ictMembersPaginationCount = 5;
//   export const disableMultiSelectBusinessType = true;
//   export const enableTradeFinanceModel = true;
//   export const enableGeoRestriction = false;
//   export const domain = isProd ? 'https://ictcircle.com/classic' : 'https://ict.tectalik.com/classic';
//   export const modernDomain = isProd ? 'https://ictcircle.com/' : 'https://ict.tectalik.com/';
  
//   export const appLinks = [
//     "https://apps.apple.com/us/app/ict-circle/id1602195040",
//     "https://play.google.com/store/apps/details?id=com.ictcircle",
//   ];
//   export const searchDropdownOptions = [
//     { key: 7, text: "All", value: "all" },
//     { key: 1, text: "Part No./SKU", value: "products" },
//     { key: 4, text: "Categories", value: "categories" },
//     { key: 6, text: "OEM/Brands", value: "oem/brands" },
//     { key: 3, text: "Distributors", value: "distributor" },
//     { key: 8, text: "Resellers", value: "reseller" },
//     { key: 5, text: "System Integrators", value: "system-integrator" },
//   ];
//   export const contactEmail = "admin@ictcircle.com";
//   export const RECAPTCHA_SITE_KEY = "6Lfr81YiAAAAAEJuW38C_Lzq9du__mn3eS25dpFp";
//   export const loggedOutInSec = 10;
